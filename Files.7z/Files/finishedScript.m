function finishedScript
load handel
sound(y,Fs)
end 